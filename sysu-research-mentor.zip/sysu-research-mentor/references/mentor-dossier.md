# Mentor Dossier and PDF

## Evidence collection

Build each research profile from a body of evidence:

- official faculty and laboratory descriptions;
- publication history across multiple years and multiple papers;
- current and completed projects, grants, patents, datasets, software, clinical trials, or field outputs as appropriate;
- representative works chosen for relevance, recency, continuity, and influence rather than a single convenient result;
- current affiliation and professional contact from official pages.

Check identity carefully for common names. Record source URL, publication/update date when available, and retrieval date.

## Group scale and output

Estimate group size only from public rosters, named current students/postdocs/staff, official annual reports, or dated recruitment pages. State the counting rule and date. If unavailable, write `未公开/待核实`.

Summarize output over a disclosed window, normally the latest 3-5 complete years. Use field-appropriate indicators: publication count and venues, author position/corresponding role, books, datasets, software, patents, clinical impact, policy work, exhibitions, or other recognized outputs. Explain database coverage and avoid cross-field comparisons based on raw counts.

## Public reputation and serious claims

Search official sources, WeChat public articles, Zhihu, Xiaohongshu, Douyin, and other relevant public pages where accessible. Search both positive and negative terms, including variations of the teacher's name, laboratory, school, and major concerns the student asks to check. Treat platform content as noisy qualitative evidence.

Use four evidence grades:

- `A — authoritative`: university/agency findings, court records, journal retraction/correction/expression-of-concern notices, or other primary official records;
- `B — attributable and corroborated`: named accounts or multiple independent, specific reports with dates and details;
- `C — anecdotal`: isolated student experience or platform post;
- `D — unverifiable`: anonymous, vague, copied, deleted, or inaccessible claim.

For every retained public post, include platform, author/account when public, post date, access date, direct link, claim category, evidence grade, and a short neutral paraphrase. Do not quote more than necessary or reproduce inflammatory wording.

Publish A evidence with precise neutral wording and direct citations. Summarize B cautiously and make clear it is reported rather than adjudicated. Include C in a clearly separated `公开平台线索（未核实）` box, with its source link, so the student can decide whether to investigate; do not use it for numerical ranking and do not repeat inflammatory details. Exclude D from mentor-specific reporting, but record that the search found only unverifiable material. Do not equate absence of search results with a clean record.

For allegations about data quality, publication integrity, harassment, discrimination, retaliation, or serious misconduct, actively seek primary evidence such as the paper, journal notice, publisher correction, expression of concern, PubPeer discussion where accessible, institution statement, retraction database record, or court/agency finding. A social-media post that says a paper is questioned is not proof that misconduct occurred. Identify the paper and its status precisely before reporting it. If that cannot be done, label the item only as an unverified public concern.

For student-treatment signals, seek patterns concerning responsiveness, feedback access, respect, authorship practices, workload, graduation support, and alumni outcomes. Include positive and negative evidence under the same standard. Never reveal private student identities or personal data.

## PDF structure

Generate a dated PDF with:

1. scope, search date, databases, limitations, and evidence legend;
2. student profile and selected directions;
3. one-page overview table for all candidates;
4. one or two pages per mentor with research synthesis, representative outputs, group information, admissions evidence, reputation/integrity evidence, fit, uncertainty, and source links;
5. collaboration network and relationship evidence;
6. comparison matrix and questions to verify;
7. complete source list.

Add bookmarks or a linked table of contents when tooling permits. Keep URLs clickable. Visually render and inspect every page for clipping, broken tables, unreadable graphs, and missing Chinese glyphs before delivery.
