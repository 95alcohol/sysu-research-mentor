# Master's and PhD Admissions Verification

## Match the actual recruiting channel

Record separately:

- master's, professional master's, academic master's, direct PhD, regular PhD, or postdoctoral opportunity;
- school/department and campus;
- program name and discipline/specialty code;
- research direction stated in the catalog;
- full-time/part-time and application category where relevant;
- whether the teacher appears in the current official supervisor or admissions catalog.

Do not assume a teacher recruits through the student's current major. A teacher may supervise through another school, hospital, institute, interdisciplinary program, or specialty.

## Availability and proposed admissions

Search current-year sources first, then the previous 2-3 cycles for context:

- official admissions catalogs and supervisor lists;
- quota or vacancy notices;
- proposed-admission and transfer/reallocation announcements;
- summer-camp, recommendation-exemption, and application-assessment notices;
- official lab recruitment pages.

Use these statuses:

- `名额官方明确`: exact current-cycle quota or vacancy is officially stated;
- `已有拟录取公开证据`: official announcement links named student(s) to this mentor/program;
- `招生方向确认、名额未知`: eligibility is verified but remaining capacity is not;
- `历史上招收`: prior cycles show recruitment, not current availability;
- `课题组自述`: current lab post says it is recruiting, pending official confirmation;
- `未核实`.

Never subtract proposed admissions from a guessed quota. Note privacy-preserving facts only; do not reproduce student ID numbers, phone numbers, or unnecessary personal information.
