# Collaboration Network

## Sources

Use PubMed for biomedical fields and supplement with OpenAlex, Crossref, ORCID, Web of Science/Scopus when available, CNKI, DBLP, arXiv, publisher pages, grant databases, and official project/lab pages as appropriate. For a student considering overseas study or work, additionally identify documented international links: foreign coauthors, joint grants, visiting appointments, cotutelle/exchange programs, international society roles, and alumni destinations where public.

Download representative full text only when it is openly licensed or lawfully available from PubMed Central, an institutional repository, arXiv, or an official author copy. Otherwise use metadata/abstract pages and link to the DOI or publisher.

## Identity and edge rules

Disambiguate names using affiliation, ORCID, email, topic, coauthors, and timeline. Create an edge only with cited evidence. Classify it as:

- repeated coauthorship;
- co-corresponding authorship;
- shared grant/project;
- joint laboratory or institutional appointment;
- mentor-trainee relationship documented publicly;
- one-off coauthorship.

For corresponding authors, inspect structured metadata or the article's correspondence section when legally accessible. Do not infer corresponding status from final-author position alone. Do not infer friendship, hierarchy, influence, or current closeness from a publication edge.

## Network output

Size nodes by a disclosed, meaningful measure such as relevant output count; use color for unit or research cluster; use line style for relationship type and line weight for repeated evidence. Separate international connections that are current and repeated from one-off foreign collaborations. Include a readable edge table containing both names, relationship type, supporting works/projects, years, and source confidence. State the data window and database coverage.
