# One-Month Laboratory Observation Review

Frame this as mutual fit assessment, not surveillance. Use conversations, permitted visits, public seminars, sample tasks, and the student's direct experience. Do not encourage covert recording, deception, private-data collection, or unauthorized access.

## Four-week plan

### Week 1: Expectations and access

- Clarify research topic, expected time, meeting frequency, response channel, trial task, authorship/data rules, and near-term milestones.
- Observe whether expectations are concrete, consistent, and respectful.

### Week 2: Daily work and support

- Understand who provides day-to-day help, whether senior students mentor newcomers, how code/data/protocols are documented, and how mistakes are handled.
- Assess whether the student can realistically learn the required methods.

### Week 3: Culture and development

- Ask about feedback quality, seminar rhythm, collaboration, working hours, holidays, funding/expenses, publication expectations, graduation paths, and alumni outcomes.
- Look for patterns across several interactions rather than one unusually good or bad day.

### Week 4: Evidence review

- Compare promised and observed management practices.
- Review intellectual interest, skill growth, access to supervision, peer support, autonomy, workload sustainability, authorship/data integrity, psychological safety, and alignment with degree/career goals.
- Identify facts still requiring direct clarification.

## Check-in format

```text
Direct observations:
What others reported (source/context):
My interpretation:
How I felt and what I need:
Green flags:
Yellow flags:
Red flags:
Questions for next week:
```

Treat coercion, retaliation, discriminatory treatment, unsafe practices, pressure to falsify data, or opaque authorship demands as serious warning signs. Recommend appropriate trusted or official support channels when safety or misconduct concerns arise, without attempting to adjudicate the claim.

## Final recommendation

Tie the recommendation to the student's original priorities. Offer one of:

- continue and agree on a concrete next milestone;
- continue conditionally after clarifying named issues;
- compare one or two alternative groups;
- step back politely and preserve the relationship.

Give a short script for the next conversation and update the mentor comparison using newly observed evidence.
