# Mentor Matching Rubric

Use this rubric to organize evidence, not to declare an objectively best teacher.

## Dimensions

| Dimension | Suggested weight | Evidence |
|---|---:|---|
| Topic alignment | 20% | Current projects, recent papers, lab themes |
| Method alignment | 10% | Methods used compared with student's preferred work |
| Preparation fit | 10% | Prerequisites compared with demonstrated skills |
| Goal alignment | 10% | Exploratory project, thesis, long-term research, degree path |
| Admissions/program fit | 15% | Degree type, recruiting program/specialty, disclosed eligibility |
| Group environment fit | 15% | Verifiable management, mentoring, peer-support signals |
| Career-network fit | 10% | National mobility, documented international links, alumni/collaboration pathways |
| Practical fit | 5% | Campus, time, start date, expected continuity |
| Evidence freshness/confidence | 5% | Recency and authority of sources, identity verification |

Adjust weights when the student states a clear priority. Show the adjustment.

## Rating language

- `Strong`: direct, recent evidence supports alignment.
- `Moderate`: plausible alignment with some direct evidence.
- `Exploratory`: interesting possibility, but major facts need verification.
- `Mismatch`: a stated constraint or preference conflicts with available evidence.

Never infer mentoring quality, personality, workload, funding, admissions influence, or open positions from publication metrics. Citation counts and venue prestige may describe visibility, but they do not establish student fit. Keep publication performance, group environment, career connections, admissions evidence, and integrity checks as distinct dimensions. Normalize weights to 100% after every adjustment.

## Comparison output

Include for every candidate:

```text
Fit summary:
Best evidence:
Potential mismatch:
Questions to verify:
Source confidence:
```

If fewer than three well-supported candidates exist, return fewer and explain the evidence gap instead of padding the list.
