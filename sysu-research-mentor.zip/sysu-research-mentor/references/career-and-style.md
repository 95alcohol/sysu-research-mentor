# Career Path and Work-Style Fit

## Determine scope

Ask the student which scope is appropriate:

- `中大优先`: focus on SYSU mentors, while noting external comparators only when useful;
- `全国搜索`: search Chinese institutions by field, program, and practical constraints;
- `海外导向`: prioritize laboratories with documented international collaboration and pathways;
- `尚未确定`: present a small, comparable cross-school sample and explain the tradeoffs.

If the student has recommendation-based admission or entrance-exam options but has not chosen a target school, default to `全国搜索` after confirming the intended field and constraints. Do not assume a high academic ranking means every program is accessible; verify program-specific eligibility separately.

## Evaluate career connections

Record evidence, not impressions, for:

- repeated international coauthorship or joint projects;
- overseas visiting, exchange, cotutelle, or joint-training programs;
- documented alumni destinations and graduate placements;
- collaborations with relevant industry, hospitals, government, or research institutions;
- conference/community participation relevant to the student's target path.

State whether each link is current, repeated, and accessible to students. A prominent collaborator or overseas degree is not automatically a pathway for a new student.

## Ask about work style without profiling

Use preference questions, each with `其他（请填写）`:

- Is the priority to complete a thesis efficiently, build transferable skills, pursue competitive outputs, explore without pressure, or something else?
- Does the student prefer close direction, regular checkpoints, or wide autonomy?
- Can the student sustainably accept a high-intensity or push-heavy pace? What boundaries matter?
- Does the student prefer an established project with clear deliverables or an uncertain exploratory problem?
- How important are publication pace, technical training, work-life boundaries, peer mentoring, and overseas exposure?
- What kinds of academic-integrity or reputation uncertainty are unacceptable to the student?

Do not label the student as lazy, ambitious, resilient, fragile, introverted, extroverted, or similar traits. Translate answers into concrete fit needs: intensity, predictability, mentoring frequency, autonomy, skill-building, and risk tolerance.

## Compare fit

For each mentor, write:

```text
Student priority:
Available group evidence:
Likely fit:
Potential conflict:
What must be verified directly:
```

Do not give a high group-fit rating based solely on output volume, a charismatic public profile, or one student anecdote. Treat a student's desire to finish quickly and a desire for rigorous skill growth as valid but distinct priorities.
