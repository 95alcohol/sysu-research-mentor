# Mentor Contact Email

## Minimum confirmed facts

Collect:

- student's name, school/department, major, and year;
- reason for contacting this specific teacher;
- one research theme, paper, project, or method the student can discuss honestly;
- relevant preparation or transferable skill;
- concrete request and realistic time commitment;
- CV, transcript, portfolio, code, or writing sample availability.

If a fact is missing, use a bracketed placeholder or ask the student. Never fabricate it.

## Structure

Keep the first email concise, normally 150-250 Chinese characters or 120-200 English words unless context requires more.

1. Identify the student and purpose.
2. Explain a specific, truthful research connection.
3. Connect one or two relevant experiences or skills.
4. Make a modest request: a brief conversation, advice on preparation, or whether an appropriate opportunity exists.
5. State availability and mention attachments.
6. Close professionally.

Avoid generic praise, exaggerated claims, demands for a position, or attaching large files without reason. Address the recipient using their verified professional title. Use the language that fits the teacher's public profile and the student's ability.

## Output checklist

- Provide 2-3 specific subject lines.
- Mark every unsupported detail as a placeholder.
- Explain in one sentence what makes the email specific to this teacher.
- Suggest only relevant attachments; name files professionally.
- Provide one polite follow-up for 7-10 days later.
- Remind the student to verify the recipient's current official email before sending.
