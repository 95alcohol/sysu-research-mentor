# Research Direction Map

Generate a context-specific map of roughly 20 directions, normally 18-24. Include adjacent disciplines and smaller subfields without pretending the list is exhaustive.

## Selection method

1. Start from the student's major, courses, interests, preferred activities, goals, and constraints.
2. Include several broad parent areas, several practical or method-oriented areas, and concrete subfields under the most relevant parents.
3. Keep labels mutually understandable, but allow overlap where real research overlaps.
4. Mark 3-6 as `重点推荐`, several as `值得探索`, and the rest as `暂不优先` with a short reason.
5. Let the student add an unlisted direction through `其他（请填写）`, then incorporate it and regenerate the map if needed.

## Explain every direction

For each direction include:

```text
方向名称（通俗别名）:
主要在研究什么:
平时可能做什么:
常用方法/工具:
适合哪类兴趣:
入门门槛:
与该学生的匹配依据:
低成本试探动作:
优先级:
```

Avoid descriptions that merely repeat the title. Explain jargon on first use. A small direction must still be large enough to support multiple research questions and more than one potential mentor.
