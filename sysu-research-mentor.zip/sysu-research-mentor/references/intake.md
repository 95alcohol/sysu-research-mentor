# Student Intake

Use only questions that can change the recommendation. Ask 3-5 at a time and accept uncertainty. Fixed choices are prompts, not limits.

## Interaction rule

For every multiple-choice question:

- include `其他（请填写）`;
- allow multiple selections, free-form additions, `不确定`, and `都不符合`;
- preserve the student's wording before translating it into research concepts;
- ask an adaptive follow-up when a free-form answer introduces a new interest, method, constraint, or goal;
- never force an answer into the nearest listed option.

## Core questions

1. What is your school/department, major, year, and campus?
2. Which two or three courses, topics, or real-world questions have held your attention most? What specifically interested you?
3. Which activities do you prefer: experiments, coding/data, mathematical derivation, reading/writing, interviews/fieldwork, clinical practice, engineering/building, or `其他（请填写）`?
4. What relevant coursework, skills, projects, competitions, internships, or readings have you completed? Which can you describe honestly in an email?
5. What do you want from this experience: exploration, a first project, graduation thesis, competition, publication, postgraduate preparation, longer-term lab participation, or `其他（请填写）`?
6. How many hours per week can you reliably contribute, from when, and for how many months?
7. What is your likely next step: stay at SYSU, apply to other Chinese universities, study abroad, work, or `其他（请填写）`? How certain are you?
8. What result matters most now: finishing a thesis efficiently, learning durable skills, building a postgraduate application, aiming for high-impact outputs, or `其他（请填写）`?
9. Which work setting fits you best: clear tasks/close guidance, moderate autonomy, highly open-ended work, a fast-paced/push-heavy environment, a predictable pace, or `其他（请填写）`? What can you realistically tolerate?
10. Are there concerns you want the search to actively check, such as mentoring style, work hours, authorship/data practices, graduation pace, lab turnover, overseas pathways, or `其他（请填写）`?

## Conditional questions

- Ask for preferred campus or remote tolerance when laboratories span campuses.
- Ask about language and mathematical/programming preparation only when relevant.
- Ask whether the student prefers a defined task or an open-ended problem.
- Ask about wet-lab, fieldwork, clinical, travel, or schedule constraints when relevant.
- Ask for current candidate teachers only if the student has already explored options.
- Ask whether national search is authorized when the student has not chosen a postgraduate target school.
- Ask what level of uncertainty around disputed papers, retractions, or other reputation signals the student is comfortable investigating; do not pressure the student to accept a concern.

## Profile summary template

```text
Student facts:
- Academic context:
- Interests/questions:
- Preferred methods:
- Relevant preparation:
- Goal and time commitment:
- Career/mobility plan:
- Work-style and development priorities:
- Concerns to verify:
- Constraints:

Working hypotheses (student should confirm):
- Priority directions:
- Other directions worth browsing:
- Confidence and missing information:
```

Avoid psychometric language unless using a validated instrument with disclosed limitations. This intake is a structured conversation, not a scientific aptitude test.
